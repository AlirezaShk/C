from django.db import models
from main.models import *
from localization.models import Location

# Create your models here.
class University(models.Model):
	name = models.CharField(max_length=400)
	url = models.CharField(max_length=200, default=None)
	tags = models.JSONField(max_length=400, default=None)
	location = models.ForeignKey(Location, on_delete=models.RESTRICT)

	def __str__(self):
		return self.name

class Article(models.Model):
	title = models.CharField(max_length=400)
	url = models.CharField(max_length=200, default=None)
	tags = models.JSONField(max_length=400, default=None)

	def __str__(self):
		return self.title

class Researcher(models.Model):
	name = models.CharField(max_length=400)
	urls = models.JSONField(max_length=800, default=None)
	tags = models.JSONField(max_length=400, default=None)
	articles = models.ManyToManyField(Article)
	university = models.ForeignKey(University, on_delete=models.RESTRICT)
	
	def __str__(self):
		return self.name
